"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Scissors,
  Users,
  Settings,
  LogOut,
} from "lucide-react";
import Logo from "@/components/Logo";

const menu = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/tools", label: "Tools", icon: Scissors },
  { href: "/admin/users", label: "Pengguna", icon: Users },
  { href: "/admin/settings", label: "Pengaturan", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-64 shrink-0 flex-col border-r border-ink-line bg-ink-soft">
      <div className="flex h-16 items-center border-b border-ink-line px-6">
        <Logo />
      </div>

      <nav className="flex-1 space-y-1 px-3 py-6">
        {menu.map((item) => {
          const active =
            item.href === "/admin"
              ? pathname === "/admin"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`focus-ring group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
                active
                  ? "bg-ink text-volt"
                  : "text-mute hover:bg-ink hover:text-paper"
              }`}
            >
              <item.icon
                size={17}
                className={active ? "text-volt" : "text-mute group-hover:text-paper"}
              />
              {item.label}
              {active && (
                <span className="ml-auto h-1.5 w-1.5 rounded-full bg-volt" />
              )}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-ink-line p-3">
        <Link
          href="/"
          onClick={() => {
            document.cookie = "xikofly_session=; path=/; max-age=0";
          }}
          className="focus-ring flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-mute transition hover:bg-ink hover:text-paper"
        >
          <LogOut size={17} />
          Keluar
        </Link>
      </div>
    </aside>
  );
}
