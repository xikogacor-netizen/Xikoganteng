export default function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 font-display font-bold ${className}`}>
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M2 11L11 2L20 11L11 20L2 11Z" stroke="#D4FF3D" strokeWidth="1.6" />
        <path d="M11 6V16M6 11H16" stroke="#D4FF3D" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
      <span className="text-paper tracking-tight">
        xikofly<span className="text-volt">.tools</span>
      </span>
    </div>
  );
}
