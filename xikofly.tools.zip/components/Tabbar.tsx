"use client";

import { useState, ReactNode } from "react";

export type Tab = {
  key: string;
  label: string;
  count?: number;
  content: ReactNode;
};

export default function Tabbar({ tabs, defaultKey }: { tabs: Tab[]; defaultKey?: string }) {
  const [active, setActive] = useState(defaultKey ?? tabs[0]?.key);
  const activeTab = tabs.find((t) => t.key === active);

  return (
    <div>
      <div className="flex items-center gap-1 border-b border-ink-line">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActive(tab.key)}
            className={`focus-ring relative flex items-center gap-2 px-4 py-3 text-sm transition ${
              active === tab.key
                ? "text-paper"
                : "text-mute hover:text-paper"
            }`}
          >
            {tab.label}
            {typeof tab.count === "number" && (
              <span
                className={`rounded-full px-1.5 py-0.5 text-[11px] font-mono ${
                  active === tab.key
                    ? "bg-volt/15 text-volt"
                    : "bg-ink-line text-mute"
                }`}
              >
                {tab.count}
              </span>
            )}
            {active === tab.key && (
              <span className="absolute inset-x-4 -bottom-px h-[2px] bg-volt" />
            )}
          </button>
        ))}
      </div>
      <div className="pt-6">{activeTab?.content}</div>
    </div>
  );
}
