import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0B0D10",
          soft: "#14171C",
          line: "#22262C",
        },
        volt: {
          DEFAULT: "#D4FF3D",
          dim: "#9FBF2E",
        },
        paper: "#F5F6F2",
        mute: "#8A8F98",
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
      backgroundImage: {
        "cut-rail":
          "repeating-linear-gradient(to bottom, #22262C 0, #22262C 6px, transparent 6px, transparent 14px)",
      },
    },
  },
  plugins: [],
};
export default config;
