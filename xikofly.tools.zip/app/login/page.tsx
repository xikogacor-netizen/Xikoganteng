"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Logo from "@/components/Logo";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // DEMO ONLY: replace with real auth (NextAuth/Clerk/Supabase Auth).
    // See README.md "Menyambungkan Auth Sungguhan".
    if (!email || !password) {
      setError("Isi email dan password dulu.");
      return;
    }
    document.cookie = "xikofly_session=demo; path=/";
    router.push("/admin");
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-ink px-6">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center">
          <Logo />
        </div>
        <div className="rounded-2xl border border-ink-line bg-ink-soft p-8">
          <h1 className="font-display text-xl font-semibold text-paper">
            Masuk ke dashboard
          </h1>
          <p className="mt-1 text-sm text-mute">
            Khusus admin & tim Xikofly.tools.
          </p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-xs text-mute">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="[email protected]"
                className="focus-ring w-full rounded-lg border border-ink-line bg-ink px-3.5 py-2.5 text-sm text-paper placeholder:text-mute/60"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs text-mute">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="focus-ring w-full rounded-lg border border-ink-line bg-ink px-3.5 py-2.5 text-sm text-paper placeholder:text-mute/60"
              />
            </div>

            {error && <p className="text-xs text-red-400">{error}</p>}

            <button
              type="submit"
              className="focus-ring w-full rounded-lg bg-volt py-2.5 text-sm font-semibold text-ink transition hover:bg-volt-dim"
            >
              Masuk
            </button>
          </form>
        </div>

        <Link
          href="/"
          className="focus-ring mt-6 block text-center text-xs text-mute hover:text-paper"
        >
          ← Kembali ke beranda
        </Link>
      </div>
    </main>
  );
}
