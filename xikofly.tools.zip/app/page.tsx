import Link from "next/link";
import { Scissors, FileImage, QrCode, FileText, ArrowUpRight, Download } from "lucide-react";
import Logo from "@/components/Logo";

const tools = [
  {
    icon: Scissors,
    name: "Video Clipper",
    desc: "Potong momen terbaik dari YouTube & TikTok jadi klip pendek siap posting.",
    tag: "Unggulan",
  },
  {
    icon: FileImage,
    name: "Image Compressor",
    desc: "Kecilin ukuran gambar tanpa ngorbanin kualitas, langsung di browser.",
    tag: "Gratis",
  },
  {
    icon: FileText,
    name: "Text Summarizer",
    desc: "Ringkas artikel panjang jadi poin-poin penting dalam hitungan detik.",
    tag: "Gratis",
  },
  {
    icon: QrCode,
    name: "QR Generator",
    desc: "Bikin QR code custom buat link, wifi, atau kontak dalam sekali klik.",
    tag: "Gratis",
  },
];

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-ink">
      {/* Nav */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Logo />
        <nav className="hidden items-center gap-8 text-sm text-mute md:flex">
          <a href="#tools" className="hover:text-paper">Tools</a>
          <a href="#how" className="hover:text-paper">Cara kerja</a>
          <a href="#pricing" className="hover:text-paper">Harga</a>
        </nav>
        <Link
          href="/login"
          className="focus-ring rounded-full border border-ink-line px-4 py-2 text-sm text-paper transition hover:border-volt hover:text-volt"
        >
          Masuk
        </Link>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 pb-20 pt-12 md:pt-20">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-ink-line px-3 py-1 text-xs text-mute">
          <span className="h-1.5 w-1.5 rounded-full bg-volt" />
          Timeline tools, bukan sekadar unduh
        </div>
        <h1 className="max-w-3xl font-display text-5xl font-bold leading-[1.05] text-paper md:text-7xl">
          Potong klipnya.
          <br />
          Buang <span className="text-volt">basa-basinya.</span>
        </h1>
        <p className="mt-6 max-w-xl text-lg text-mute">
          Xikofly.tools adalah kumpulan tools ringan buat kreator: clip video,
          kompres gambar, ringkas teks, dan lainnya — semua tanpa install apa-apa.
        </p>

        <div className="mt-9 flex flex-wrap items-center gap-4">
          <a
            href="#tools"
            className="focus-ring inline-flex items-center gap-2 rounded-full bg-volt px-6 py-3 text-sm font-semibold text-ink transition hover:bg-volt-dim"
          >
            Mulai clip <ArrowUpRight size={16} />
          </a>
          <Link
            href="/login"
            className="focus-ring inline-flex items-center gap-2 rounded-full border border-ink-line px-6 py-3 text-sm text-paper transition hover:border-volt hover:text-volt"
          >
            Masuk sebagai admin
          </Link>
        </div>

        {/* Timeline scrubber signature element */}
        <div className="mt-16 rounded-2xl border border-ink-line bg-ink-soft p-6">
          <div className="mb-4 flex items-center justify-between text-xs text-mute">
            <span className="font-mono">00:00:12</span>
            <span className="font-mono text-volt">CLIP_04.mp4</span>
            <span className="font-mono">00:00:47</span>
          </div>
          <div className="relative h-16 overflow-hidden rounded-lg bg-ink">
            <div className="absolute inset-0 flex items-center gap-[3px] px-2">
              {Array.from({ length: 60 }).map((_, i) => (
                <span
                  key={i}
                  className="w-1 rounded-full bg-ink-line"
                  style={{ height: `${20 + ((i * 37) % 60)}%` }}
                />
              ))}
            </div>
            <div className="absolute inset-y-0 left-[22%] w-[34%] border-x-2 border-volt bg-volt/10" />
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="mx-auto max-w-6xl cut-line" />

      {/* Tools grid */}
      <section id="tools" className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="mb-2 font-mono text-xs uppercase tracking-widest text-volt">
              Toolset
            </p>
            <h2 className="font-display text-3xl font-bold text-paper md:text-4xl">
              Semua tools kamu, satu tempat
            </h2>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {tools.map((tool) => (
            <div
              key={tool.name}
              className="group rounded-2xl border border-ink-line bg-ink-soft p-6 transition hover:border-volt/60"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-ink text-volt">
                  <tool.icon size={18} />
                </div>
                <span className="rounded-full border border-ink-line px-2.5 py-1 text-[11px] text-mute">
                  {tool.tag}
                </span>
              </div>
              <h3 className="font-display text-lg font-semibold text-paper">
                {tool.name}
              </h3>
              <p className="mt-2 text-sm text-mute">{tool.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="mx-auto max-w-6xl px-6 py-10">
        <div className="cut-line mb-6" />
        <div className="flex flex-col items-center justify-between gap-4 text-xs text-mute md:flex-row">
          <Logo className="text-sm" />
          <p className="flex items-center gap-1">
            <Download size={12} /> Dibangun buat kreator. © {new Date().getFullYear()} Xikofly.tools
          </p>
        </div>
      </footer>
    </main>
  );
}
