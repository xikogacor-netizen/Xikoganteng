import Tabbar from "@/components/Tabbar";
import { Scissors, FileImage, QrCode, FileText } from "lucide-react";

const allTools = [
  { name: "Video Clipper", icon: Scissors, status: "Aktif", uses: "12,204" },
  { name: "Image Compressor", icon: FileImage, status: "Aktif", uses: "8,432" },
  { name: "Text Summarizer", icon: FileText, status: "Aktif", uses: "3,120" },
  { name: "QR Generator", icon: QrCode, status: "Nonaktif", uses: "981" },
];

function ToolsTable({ filter }: { filter?: string }) {
  const rows = filter ? allTools.filter((t) => t.status === filter) : allTools;
  return (
    <div className="overflow-hidden rounded-2xl border border-ink-line bg-ink-soft">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-ink-line text-xs text-mute">
            <th className="px-5 py-3 font-normal">Tool</th>
            <th className="px-5 py-3 font-normal">Status</th>
            <th className="px-5 py-3 font-normal">Total pemakaian</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((tool) => (
            <tr key={tool.name} className="border-b border-ink-line last:border-0">
              <td className="flex items-center gap-3 px-5 py-4 text-paper">
                <tool.icon size={16} className="text-volt" />
                {tool.name}
              </td>
              <td className="px-5 py-4">
                <span
                  className={`rounded-full px-2.5 py-1 text-xs ${
                    tool.status === "Aktif"
                      ? "bg-volt/15 text-volt"
                      : "bg-ink-line text-mute"
                  }`}
                >
                  {tool.status}
                </span>
              </td>
              <td className="px-5 py-4 font-mono text-mute">{tool.uses}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AdminToolsPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-paper">Tools</h1>
      <p className="mt-1 text-sm text-mute">Kelola tools yang tersedia di Xikofly.tools.</p>

      <div className="mt-6">
        <Tabbar
          tabs={[
            { key: "all", label: "Semua", count: allTools.length, content: <ToolsTable /> },
            {
              key: "active",
              label: "Aktif",
              count: allTools.filter((t) => t.status === "Aktif").length,
              content: <ToolsTable filter="Aktif" />,
            },
            {
              key: "inactive",
              label: "Nonaktif",
              count: allTools.filter((t) => t.status === "Nonaktif").length,
              content: <ToolsTable filter="Nonaktif" />,
            },
          ]}
        />
      </div>
    </div>
  );
}
