import Sidebar from "@/components/Sidebar";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex bg-ink">
      <Sidebar />
      <div className="flex-1">
        <header className="flex h-16 items-center justify-between border-b border-ink-line px-8">
          <p className="text-sm text-mute">
            Admin <span className="text-ink-line">/</span>{" "}
            <span className="text-paper">Dashboard</span>
          </p>
          <div className="flex items-center gap-3">
            <span className="h-2 w-2 rounded-full bg-volt" />
            <span className="text-xs text-mute">Sesi demo aktif</span>
          </div>
        </header>
        <main className="p-8">{children}</main>
      </div>
    </div>
  );
}
