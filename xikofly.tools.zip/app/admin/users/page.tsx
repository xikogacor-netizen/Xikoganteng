import Tabbar from "@/components/Tabbar";

const users = [
  { name: "Budi Santoso", email: "budi@mail.com", plan: "Premium", status: "Active" },
  { name: "Sinta Wulandari", email: "sinta@mail.com", plan: "Free", status: "Active" },
  { name: "Rafi Ahmad", email: "rafi@mail.com", plan: "Free", status: "Banned" },
  { name: "Dewi Lestari", email: "dewi@mail.com", plan: "Premium", status: "Pending" },
];

function UsersTable({ filter }: { filter?: string }) {
  const rows = filter ? users.filter((u) => u.status === filter) : users;
  return (
    <div className="overflow-hidden rounded-2xl border border-ink-line bg-ink-soft">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-ink-line text-xs text-mute">
            <th className="px-5 py-3 font-normal">Nama</th>
            <th className="px-5 py-3 font-normal">Email</th>
            <th className="px-5 py-3 font-normal">Paket</th>
            <th className="px-5 py-3 font-normal">Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((u) => (
            <tr key={u.email} className="border-b border-ink-line last:border-0">
              <td className="px-5 py-4 text-paper">{u.name}</td>
              <td className="px-5 py-4 font-mono text-mute">{u.email}</td>
              <td className="px-5 py-4 text-mute">{u.plan}</td>
              <td className="px-5 py-4">
                <span
                  className={`rounded-full px-2.5 py-1 text-xs ${
                    u.status === "Active"
                      ? "bg-volt/15 text-volt"
                      : u.status === "Banned"
                      ? "bg-red-400/15 text-red-400"
                      : "bg-ink-line text-mute"
                  }`}
                >
                  {u.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AdminUsersPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-paper">Pengguna</h1>
      <p className="mt-1 text-sm text-mute">Kelola akun yang terdaftar di Xikofly.tools.</p>

      <div className="mt-6">
        <Tabbar
          tabs={[
            { key: "active", label: "Active", count: users.filter(u => u.status === "Active").length, content: <UsersTable filter="Active" /> },
            { key: "pending", label: "Pending", count: users.filter(u => u.status === "Pending").length, content: <UsersTable filter="Pending" /> },
            { key: "banned", label: "Banned", count: users.filter(u => u.status === "Banned").length, content: <UsersTable filter="Banned" /> },
            { key: "all", label: "Semua", count: users.length, content: <UsersTable /> },
          ]}
        />
      </div>
    </div>
  );
}
