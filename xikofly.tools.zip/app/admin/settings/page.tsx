export default function AdminSettingsPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-paper">Pengaturan</h1>
      <p className="mt-1 text-sm text-mute">
        Konfigurasi umum Xikofly.tools.
      </p>

      <div className="mt-6 max-w-lg space-y-4 rounded-2xl border border-ink-line bg-ink-soft p-6">
        <div>
          <label className="mb-1.5 block text-xs text-mute">Nama situs</label>
          <input
            defaultValue="Xikofly.tools"
            className="focus-ring w-full rounded-lg border border-ink-line bg-ink px-3.5 py-2.5 text-sm text-paper"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-xs text-mute">Batas klip harian (gratis)</label>
          <input
            defaultValue="5"
            className="focus-ring w-full rounded-lg border border-ink-line bg-ink px-3.5 py-2.5 text-sm text-paper"
          />
        </div>
        <button className="focus-ring rounded-lg bg-volt px-5 py-2.5 text-sm font-semibold text-ink hover:bg-volt-dim">
          Simpan perubahan
        </button>
      </div>
    </div>
  );
}
