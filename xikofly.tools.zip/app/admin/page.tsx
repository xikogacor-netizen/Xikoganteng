import Tabbar from "@/components/Tabbar";
import { Scissors, Users, Zap, TrendingUp } from "lucide-react";

const stats = [
  { label: "Klip dibuat hari ini", value: "1,204", icon: Scissors, delta: "+12%" },
  { label: "Pengguna aktif", value: "8,932", icon: Users, delta: "+4%" },
  { label: "Job antrian", value: "37", icon: Zap, delta: "-8%" },
  { label: "Konversi ke premium", value: "3.2%", icon: TrendingUp, delta: "+0.4%" },
];

function StatCard({ stat }: { stat: (typeof stats)[number] }) {
  const positive = stat.delta.startsWith("+");
  return (
    <div className="rounded-2xl border border-ink-line bg-ink-soft p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-ink text-volt">
          <stat.icon size={16} />
        </div>
        <span
          className={`font-mono text-xs ${positive ? "text-volt" : "text-mute"}`}
        >
          {stat.delta}
        </span>
      </div>
      <p className="font-display text-2xl font-bold text-paper">{stat.value}</p>
      <p className="mt-1 text-xs text-mute">{stat.label}</p>
    </div>
  );
}

function OverviewTab() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="rounded-2xl border border-ink-line bg-ink-soft p-6">
        <h3 className="font-display text-sm font-semibold text-paper">
          Aktivitas terbaru
        </h3>
        <ul className="mt-4 space-y-3 text-sm">
          {[
            ["budi@_", "clip video 00:23", "2 menit lalu"],
            ["sinta@_", "compress 14 gambar", "9 menit lalu"],
            ["rafi@_", "generate QR code", "22 menit lalu"],
          ].map(([user, action, time]) => (
            <li key={user} className="flex items-center justify-between border-b border-ink-line pb-3 last:border-0 last:pb-0">
              <div>
                <p className="text-paper">{user}</p>
                <p className="text-xs text-mute">{action}</p>
              </div>
              <span className="font-mono text-xs text-mute">{time}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="rounded-2xl border border-ink-line bg-ink-soft p-6">
        <h3 className="font-display text-sm font-semibold text-paper">
          Status antrian job clipper
        </h3>
        <div className="mt-4 space-y-3">
          {[
            ["Diproses", 12, "text-volt"],
            ["Menunggu", 25, "text-mute"],
            ["Gagal", 2, "text-red-400"],
          ].map(([label, count, color]) => (
            <div key={label as string} className="flex items-center justify-between text-sm">
              <span className="text-paper">{label}</span>
              <span className={`font-mono ${color}`}>{count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AlertsTab() {
  return (
    <div className="rounded-2xl border border-ink-line bg-ink-soft p-6 text-sm text-mute">
      Belum ada alert. Sambungkan monitoring (mis. Sentry / Better Stack) buat
      nampilin error rate worker clipper di sini.
    </div>
  );
}

export default function AdminDashboardPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-paper">Dashboard</h1>
      <p className="mt-1 text-sm text-mute">Ringkasan performa Xikofly.tools.</p>

      <div className="my-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <StatCard key={s.label} stat={s} />
        ))}
      </div>

      <Tabbar
        tabs={[
          { key: "overview", label: "Ringkasan", content: <OverviewTab /> },
          { key: "alerts", label: "Alert", count: 0, content: <AlertsTab /> },
        ]}
      />
    </div>
  );
}
